import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Olá, mundo!</h1>
      </header>
    </div>
  );
}

export default App;
