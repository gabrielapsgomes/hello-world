import Title from './components/Title'
import Relogio from './components/Relogio'
import Subtitulo from './components/Subtitulo'
import LowerCase from './components/LowerCase'
import UpperCase from './components/UpperCase'
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Olá, mundo!</h1>
        <Title />
        <Relogio />
        <Subtitulo>publicações</Subtitulo>
        <Subtitulo>seguidores</Subtitulo>
        <Subtitulo>seguindo</Subtitulo>
        <LowerCase texto='TEXTOMAIUSCULO' />
        <UpperCase texto='textomaiusculo' />
      </header>
    </div>
  );
}

export default App;
