function Title() {
return(
    <h1>Eu sou um título do componente Title</h1>
)
}

export default Title