const Subtitulo = (props) => {
return(
    <h4>{props.children}</h4>
)
}

export default Subtitulo


// <img src=''/>
// <span>publicações</span>

//<Subtitulo texto='publicações'/>
//<Subtitulo texto='seguidores'/>
//<Subtitulo texto='seguindo'/>